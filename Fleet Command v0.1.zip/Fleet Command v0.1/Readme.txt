To Install
----------------------
Unzip anywhere, Fleet Command.exe to run.

To set Resolution
----------------------
Open resolution.ini and enter the resolution in the format

width
height

Controls
----------------------
Select		Left Click
Action		Right Click
Move		Arrow Keys or WASD
Zoom		Mouse Wheel

Game Info
----------------------
To select a unit click or drag a box around the unit
To attack a unit right click on that unit
To collect resources right click on the resource with a capital ship selected
To dock a ship at a capital ship, select a ship and right click on a captial ship.
To build select a captial ship, go to the wrench menu and click a unit image.
	Cancel by clicking the unit in the queue at the bottom
To launch a docked unit, select a captial ship, go to the arrow menu and click the ship image.

Win by destroying all enemies